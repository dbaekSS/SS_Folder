package exercises;

public class Ex_1 {

	public static void main(String[] args) {
		System.out.print("1)\r\n" + 
				"*\r\n" + 
				"**\r\n" + 
				"***\r\n" + 
				"****\r\n" + 
				".........\r\n" + 
				"2)\r\n" + 
				"..........\r\n" + 
				"****\r\n" + 
				"***\r\n" + 
				"**\r\n" + 
				"*\r\n" + 
				"3)\r\n" + 
				"     *\r\n" + 
				"    ***\r\n" + 
				"   *****\r\n" + 
				"  *******\r\n" + 
				"...........\r\n" + 
				"4)\r\n" + 
				"............\r\n" + 
				"  *******\r\n" + 
				"   *****\r\n" + 
				"    ***\r\n" + 
				"     *");
	}
}
