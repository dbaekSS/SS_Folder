/**
 * 
 */
package com.ss.jb.one;
//package is usually (.com/.gov/.org, company name, project name, part of project)
/**
 * @author dbaek
 *
 */
public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
